(function ( $ ) {
	window.InlineShortcodeView_vc_row_inner = window.InlineShortcodeView_vc_row.extend( {
		column_tag: 'vc_column_inner'
	} );
})( window.jQuery );